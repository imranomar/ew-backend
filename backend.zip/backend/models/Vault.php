<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "vault".
 *
 * @property string $id
 * @property string $name
 * @property string $number
 * @property string $cvcode
 * @property string $expiry_month
 * @property string $expiry_year
 */
class Vault extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'vault';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name', 'number', 'cvcode', 'expiry_month', 'expiry_year'], 'required'],
            [['cvcode', 'expiry_month', 'expiry_year'], 'integer'],
            [['name'], 'string', 'max' => 200],
            [['number'], 'string', 'max' => 16],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'number' => 'Number',
            'cvcode' => 'Cvcode',
            'expiry_month' => 'Expiry Month',
            'expiry_year' => 'Expiry Year',
        ];
    }

    /**
     * @inheritdoc
     * @return VaultQuery the active query used by this AR class.
     */
    public static function find()
    {
        return new VaultQuery(get_called_class());
    }
}
